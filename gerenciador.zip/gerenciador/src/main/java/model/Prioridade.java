package model;

public enum Prioridade {
    BAIXA,
    MEDIA,
    ALTA
}